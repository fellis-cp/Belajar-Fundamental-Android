# BFA-V2
BFA Dicoding Submssion 1

![Screenshot 2023-09-26 081652](https://github.com/fellis-cp/BFA-V2/assets/60042724/6c19f28f-62a4-47c1-b467-fb87317e9f5c)

 
